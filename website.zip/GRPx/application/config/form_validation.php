<?php
$config = array(

	'student' => array(

			array(
				'field' => 'stuID',
				'label' => 'student ID',
				'rules' => 'required|isset|alpha_dash'
				),

			array(
				'field' => 'stuPW',
				'label' => 'password',
				'rules' => 'required|isset|alpha_dash'
				)
		),

	'tutor' => array(


			array(
				'field' => 'tutorID',
				'label' => 'tutor ID',
				'rules' => 'required|isset|alpha_dash'
				),

			array(
				'field' => 'tutorPW',
				'label' => 'password',
				'rules' => 'required|isset|alpha_dash'
				)

		),

	'admin' => array(


			array(
				'field' => 'adminID',
				'label' => 'administrators ID',
				'rules' => 'required|isset|alpha_dash'
				),

			array(
				'field' => 'adminPW',
				'label' => 'password',
				'rules' => 'required|isset|alpha_dash'
				)

		),

	'course' => array(


			array(
				'field' => 'courseCode',
				'label' => 'course code',
				'rules' => 'required|isset|alpha_dash|max_length[20]'
				),

			array(
				'field' => 'courseName',
				'label' => 'course name',
				'rules' => 'required|isset|alpha_dash|max_length[50]'
				),

			array(
				'field' => 'courseDesc',
				'label' => 'course description',
				'rules' => 'required|isset'
				),			

		),

	'email' => array(

			array(
				'field' => 'subject',
				'label' => 'email subject',
				'rules' => 'required|isset|alpha_dash|max_length[50]'
				),

			array(
				'field' => 'content',
				'label' => 'email content',
				'rules' => 'required|isset|alpha_dash|max_length[500]'
				),	
		),
	
	'module' => array(


			array(
				'field' => 'moduleCode',
				'label' => 'module code',
				'rules' => 'required|isset|alpha_dash|max_length[20]'
				),

			array(
				'field' => 'moduleName',
				'label' => 'module name',
				'rules' => 'required|isset|alpha_dash|max_length[50]'
				),

			array(
				'field' => 'moduleCredit',
				'label' => 'module credits',
				'rules' => 'required|isset|integer|greater_than[0]|less_than[130]'
				),			

			array(
				'field' => 'moduleLevel',
				'label' => 'module level',
				'rules' => 'required|isset|integer|greater_than[0]|less_than[4]'
				),

			array(
				'field' => 'moduleWebCourseID',
				'label' => 'module web course ID',
				'rules' => 'required|isset|alpha_dash'
				),

			array(
				'field' => 'moduleWebYearID',
				'label' => 'module web year ID',
				'rules' => 'required|isset|alpha_dash'
				),
		),

	);
