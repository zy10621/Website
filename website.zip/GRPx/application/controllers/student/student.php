<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
    }

	public function index(){

		$this->checkLogin();

		$stuID = $this->session_model->getStudentLoginID();

		$courseCode = $this->module_model->getCourseCode($stuID);

		$data['isloggedin'] = $this->session_model->isStudentLogin();
		$data['studentName'] = $this->session_model->getStudentLoginName();
		$data['stuID'] = $stuID;
		$data['courseCode'] = $courseCode;

		$data['finished'] = $this->student_model->checkFinished($stuID);
		$data['compulsory'] = $this->module_model->getCompulsory($stuID, $courseCode);
		$data['notChosen'] = $this->module_model->getNotChosen($stuID, $courseCode);
		$data['chosen'] = $this->module_model->getChosen($stuID, $courseCode);
		$data['total'] = $this->module_model->calTotal($stuID);

		$this->load->view('student/student_index.html', $data);
	}

	public function checkLogin(){

		$isloggedin = $this->session_model->isStudentLogin();

		if(!$isloggedin){
			redirect('student/login/index');
		}
	}

	public function addModule(){

		$this->checkLogin();

		$stuID = $this->session_model->getStudentLoginID();

		$moduleCode = $cid = $this->uri->segment(4);

		$data = array(
					'studentID' => $stuID,
					'moduleCode' => $moduleCode
				);

		$this->module_model->addModule($data);

		$this->viewModule();
	}

	public function viewModule(){

		$this->checkLogin();

		$stuID = $this->session_model->getStudentLoginID();
		$courseCode = $this->module_model->getCourseCode($stuID);

		$data['finished'] = $this->student_model->checkFinished($stuID);
		$data['compulsory'] = $this->module_model->getCompulsory($stuID, $courseCode);
		$data['notChosen'] = $this->module_model->getNotChosen($stuID, $courseCode);
		$data['chosen'] = $this->module_model->getChosen($stuID, $courseCode);
		$data['total'] = $this->module_model->calTotal($stuID);

		$this->load->view('student/modules.php',$data);
	}

	public function deleteModule(){

		$this->checkLogin();

		$stuID = $this->session_model->getStudentLoginID();
		$moduleCode = $cid = $this->uri->segment(4);

		$data = array(
					'studentID' => $stuID,
					'moduleCode' => $moduleCode
				);

		$this->module_model->deleteModule($data);
		
		$this->viewModule();
	}

	public function submitModule(){

		$this->checkLogin();

		$stuID = $this->session_model->getStudentLoginID();

		$data['result'] = $this->submit_model->index($stuID);
		
		if($data['result']['condition'] == 0){
			$this->student_model->finish($stuID);
			$this->load->view('student/success.html', $data);			
		} else {
			$this->load->view('student/failure.html', $data);
		}
	}

	public function resetProcessing(){
		$this->checkLogin();

		$this->load->view('student/processing.html');
	}

	public function resetPage(){
		$this->checkLogin();

		redirect('student/student/index');
	}

	public function sendMails(){

		$this->checkLogin();

    // $fp = fsockopen("www.google.com", 80, $errno, $errstr, 10); // work fine
    // if (!$fp)
    //     echo "www.google.com -  $errstr   ($errno)<br>\n";
    // else
    //     echo "www.google.com -  ok<br>\n";


    // $fp = fsockopen("smtp.gmail.com", 465, $errno, $errstr, 10); // NOT work
    // if (!$fp)
    //     echo "smtp.gmail.com 465  -  $errstr   ($errno)<br>\n";
    // else
    //     echo "smtp.gmail.com 465 -  ok<br>\n";


    // $fp = fsockopen("smtp.gmail.com", 587, $errno, $errstr, 10); // NOT work
    // if (!$fp)
    //     echo "smtp.gmail.com 587  -  $errstr   ($errno)<br>\n";
    // else
    //     echo "smtp.gmail.com 587 -  ok<br>\n";
		
		$subject = $this->input->post('subject');
		$content = $this->input->post('content');

		$this->load->library('form_validation');
		$status = $this->form_validation->run('email');


		$this->load->library('email');

		$this->email->clear();
		$this->email->from('shadowcabinet.sc@gmail.com', 'TheShadowCabinetTeam');
		$this->email->to('shadowcabinet.schooloffice@gmail.com');
		$this->email->subject($subject);
		$this->email->message($content);
		if($this->email->send()){
			$this->sendResponse();
		}		
		return 1;
	}

	public function sendResponse(){

		$this->checkLogin();

		$stuID = $this->session_model->getStudentLoginID();
		$stuName = $this->session_model->getStudentLoginName();
		$studentMail = $stuID . "@nottingham.ac.uk";
		
		$this->load->library('email');

		$this->email->clear();
		$this->email->from('shadowcabinet.sc@gmail.com', 'TheShadowCabinetTeam');
		$this->email->to($studentMail);
		$this->email->subject('[ShadowCabinetSchoolOffice]Your request has been received.');
		$this->email->message('Dear'. $stuName .' :\r\n Thank you for emailing. We have received your request. 
			We will concat you for a later response soon.');
		$this->email->send();
	}


}