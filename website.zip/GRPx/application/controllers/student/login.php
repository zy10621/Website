<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Login extends CI_Controller{

	public function index(){
		$this->load->helper('form');
		$this->load->view('student/login.html');
	}

	public function check_login(){

		$this->load->library('form_validation');
		$status = $this->form_validation->run('student');

		if ($status){

			$studentID = $this->input->post('stuID');

			$studentPW = md5($this->input->post('stuPW'));
			
			$this->load->model('student_model', 'student');
			$stuData = $this->student->check($studentID);

			if(!$stuData || md5($stuData[0]['studentPW']) != $studentPW){
				
				//need an error infromation here
				$data['error'] = 1;

				$this->load->helper('form');
				$this->load->view('student/login.html', $data);
			} else {

				//correct input
				$studentName = $this->student->getName($studentID);
				$this->session_model->setStudentLogin($studentID, $studentName);

				redirect('student/student/index');
			}
		} else {

			//invalid input
			$this->load->helper('form');
			$this->load->view('student/login.html');
		}
	}

	public function studentlogout(){
		
		$this->session_model->studentLogOut();
		
		$this->load->helper('form');
		redirect('student/login/index');
	}
}