<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Login extends CI_Controller{

	public function index(){
		$this->load->helper('form');
		$this->load->view('admin/login.html');
	}
	
	public function check_login(){

		$this->load->library('form_validation');
		$status = $this->form_validation->run('admin');

		if ($status){

			$adminID = $this->input->post('adminID');

			$adminPW = md5($this->input->post('adminPW'));
			
			$adminData = $this->admin_model->check($adminID);

			if(!$adminData || md5($adminData[0]['adminPW']) != $adminPW){
				
				$data['error'] = 1;

				$this->load->helper('form');
				$this->load->view('admin/login.html', $data);
			} else {

				//correct input
				$adminName = $this->admin_model->getName($adminID);
				$this->session_model->setAdminLogin($adminID, $adminName);

				redirect('/admin/admin/index');
			}
		} else {

			//invalid input
			$this->load->helper('form');
			$this->load->view('admin/login.html');
		}
	}

	public function adminlogout(){
		
		$this->session_model->adminLogOut();
		
		$this->load->helper('form');
		redirect('admin/login/index');
	}
}