<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Student extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
    }

    public function checkLogin(){

        $isloggedin = $this->session_model->isAdminLogin();

        if(!$isloggedin){
            redirect('admin/login/index');
        }
    }

    public function index(){

        $this->checkLogin();

        $students = $this->admin_model->getStudents();
        $this->studentPage($students[0]['studentID']);
    }

    public function students(){

        $this->checkLogin();

        $studentID = $this->uri->segment(4);

        $this->studentPage($studentID);
    }


    public function studentPage($studentID){

        $this->checkLogin();
        $data = $this->getDatas($studentID);
        $this->load->view('admin/students.html', $data);
    }

    private function getDatas($studentID){

        $this->checkLogin();
        $courseCode = $this->admin_model->getCourseCodeByStudent($studentID);
        $level = $this->admin_model->getLevelBySdudent($studentID);

        $data['selectedStudent'] = $studentID;
        $data['compulsory'] = $this->admin_model->getCompulsory($courseCode, $level);
        $data['selectedStudentName'] = $this->admin_model->getStudentNameByID($studentID);
        $data['students'] = $this->admin_model->getStudents();
        $data['modulesNotWithStudent'] = $this->admin_model->getModulesNotWithStudent($studentID, $level , $courseCode);
        $data['module'] = $this->admin_model->getModuleByStudent($studentID);

        return $data;
    }

    public function mainStudent(){

        $this->checkLogin();
        $studentID = $this->input->post('studentID');
        $data = $this->getDatas($studentID);

        $this->load->view('admin/mainstudent.html', $data);
    }

    public function getModuleByRegexp(){

        $this->checkLogin();

        $studentID = $this->input->post('studentID');
        $regexp = $this->input->post('regexp');
        $courseCode = $this->admin_model->getCourseCodeByStudent($studentID);
        $level = $this->admin_model->getLevelBySdudent($studentID);

        if($regexp == ""){
            $regexp = ".*";
        }
        
        $data = $this->getDatas($studentID);
        $data['module'] = $this->admin_model->getStudentModuleByRegexp($studentID, $regexp);
        $data['compulsory'] = $this->admin_model->getStuComModuleByRegexp($courseCode, $regexp, $level);
        $this->load->view('admin/studenttable.html', $data);
    }

    public function addModule(){

        $this->checkLogin();

        $studentID = $this->input->post('studentID');
        $moduleCode = $this->input->post('moduleCode');

        $result = $this->admin_model->addModuleIntoStudent($studentID, $moduleCode);
        
        $data = $this->getDatas($studentID);

        if ($result == 1) {
            $data['formMessage'] = "Successfully enrolled " . $studentID . " onto  " . $moduleCode . "." ;
        } else {
            $data['formMessage'] = "Failed to enroll student " . $studentID . " onto " . $moduleCode . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainstudent.html', $data);
    }

    public function deleteModule(){

        $this->checkLogin();

        $studentID = $this->input->post('studentID');
        $moduleCode = $this->input->post('moduleCode');

        $result = $this->admin_model->deleteModuleByStudent($studentID, $moduleCode);

        $data = $this->getDatas($studentID);

        if ($result == 1) {
            $data['formMessage'] = "Successfully removed " . $moduleCode . " from " . $studentID . "." ;
        } else {
            $data['formMessage'] = "Failed to remove " . $moduleCode . " form " . $studentID . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainstudent.html', $data);

    }

    public function setStudent(){

        $this->checkLogin();

        $studentID = $this->input->post('studentID');

        $result = $this->admin_model->setStudent($studentID);

        $data = $this->getDatas($studentID);

        if($result){
            $data['formMessage'] = 'Successfully set student ' . $studentID . 'to complete.';
        } else {
            $data['formMessage'] = 'Failed to set student ' . $studentID . 'to complete: Please check your choice.';
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainstudent.html', $data); 
    }

    public function resetStudent(){

        $this->checkLogin();

        $studentID = $this->input->post('studentID');

        $result1 = $this->admin_model->deleteModulesFromStudent($studentID);
        $result2 = $this->admin_model->resetStudent($studentID);

        $data = $this->getDatas($studentID);

        if(!($result1)){
            $data['formMessage'] = "Failed to reset student " . $studentID . " : cannot delete modules.";
        } elseif (!($result2)){
            $data['formMessage'] = "Failed to reset student " . $studentID . " : cannot reset choice .";
        } else {
            $data['formMessage'] = "Successfully reset student " . $studentID  . ".";
        }

        $data['formResult'] = $result1 && $result2;
        $data['formSet'] = 1;

        $this->load->view('admin/mainstudent.html', $data); 
    }
}

