<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Admin extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
    }
    /**
     * this is a test
     * @return void
     */
    public function index(){

    	$this->checkLogin();

    	$data['finishedRegested'] = $this->admin_model->getFinishedStudent();
    	$data['totalFinished'] = count($data['finishedRegested']);
    	$data['studentsCountDetail'] = $this->admin_model->getStudentsCountDetail();

    	$this->load->view('admin/index.html',$data);

    }

	public function checkLogin(){

		$isloggedin = $this->session_model->isAdminLogin();

		if(!$isloggedin){
			redirect('admin/login/index');
		}
	}


	public function course(){

		$this->checkLogin();

		$courses = $this->course_model->getCourses();

		if(!count($courses)){
			redirect('admin/courses_empty.html');
		}else{
			$this->coursePage($courses[0]['courseCode']);
		}
	}

	public function coursePage($code){

		$this->checkLogin();

		if(($courseCode = $this->input->post('courseCode')) == ""){
			$courseCode = $code;
		}

		$data = $this->getDatas($courseCode);
		$this->load->view('admin/courses.html', $data);
	}

	public function mainCourse(){

		$this->checkLogin();

		$courseCode = $this->input->post('courseCode');

		$data = $this->getDatas($courseCode);
		$this->load->view('admin/maincourse.html', $data);
	}

	public function getDatas($courseCode){

		$this->checkLogin();

		$data['courses']        = $this->course_model->getCourses();
		$data['selectedCourse'] = $courseCode;
		$data['notInCourse']    = $this->course_model->getModulesNotInCourse($courseCode);
		$data['modules']        = $this->course_model->getModulesByCourse($courseCode);
		return $data;
	}

	public function deleteModuleFromCourse(){

		$this->checkLogin();

		$moduleCode = $this->input->post('moduleCode');
		$courseCode = $this->input->post('courseCode');

		$this->course_model->deleteModuleFromCourse($moduleCode,$courseCode);

		$data = $this->getDatas($courseCode);
		$data['formMessage'] = "Successfully delete module " . $moduleCode . " from " . $courseCode . "." ;
		$data['formResult'] = 1;
		$data['formSet'] = 1;
		
		$this->load->view('admin/maincourse.html',$data);
	}

	public function courseTable(){

		$this->checkLogin();

		$courseCode = $this->input->post('courseCode');

		$data= $this->getDatas($courseCode);
		$this->load->view('admin/courseTable.html', $data);
	}

	public function getModuleByRegexp(){

		$this->checkLogin();

		$regexp = $this->input->post('regexp');
		$courseCode = $this->input->post('courseCode');

		if($regexp == ""){
			$regexp = ".*";
		}

		$data = $this->getDatas($courseCode);
		$data['modules']=$this->course_model->getModuleByRegex($courseCode,$regexp);
		$this->load->view('admin/courseTable.html', $data);
	}


	public function addModuleIntoCourse(){

		$this->checkLogin();

		$moduleCode = $this->input->post('moduleCode');
		$courseCode = $this->input->post('courseCode');
		$compulsory = $this->input->post('compulsory');

		$result = $this->course_model->addModule($moduleCode, $courseCode, $compulsory);

		$data = $this->getDatas($courseCode);

		if ($result == 1) {
			$data['formMessage'] = "Successfully add module " . $moduleCode . " into " . $courseCode . "." ;
		} else {
			$data['formMessage'] = "Failed to add " . $moduleCode . " into " . $courseCode . " : please check your input.";	
 		}

		$data['formResult'] = $result;
		$data['formSet'] = 1;

		$this->load->view('admin/maincourse.html', $data);
	}

	public function addcourseFromEmpty(){

		$this->checkLogin();

		$courseCode = $this->input->post('courseCode');
		$courseName = $this->input->post('courseName');
		$courseDesc = $this->input->post('courseDesc');
		$selectedCourse = $this->input->post('selectedCourse');

		$this->load->library('form_validation');
		$status = $this->form_validation->run('course');

		if ($status){

			$exist = $this->course_model->checkCourseExist($courseCode);

			if(count($exist)){

				$data['addCourseError'] = 2;
				$this->load->view('admin/courses_empty.html', $data);

			} else {

				$result = $this->course_model->insertCourse($courseCode, $courseName, $courseDesc);

				$data = $this->getDatas($courseCode);

				if ($result == 1){
					$data['formMessage'] = "Successfully add a new course " . $courseCode . " : " . $courseName . ".";
				} else {
					$data['formMessage'] = "Failed to add a new course " . $courseCode . " : " . $courseName . ".";
				}

				$data['formResult'] = $result;
				$data['formSet'] = 1;

				redirect('admin/admin/course');
			}
		} else {

			$this->load->helper('form');
			$data = $this->getDatas($selectedCourse);
			$data['addCourseError'] = 1;
			$this->load->view('admin/courses_empty.html', $data);
		}
	}

	public function test(){
		$this->load->view('admin/courses_empty.html');
	}

	public function addcourse(){

		$this->checkLogin();

		$courseCode = $this->input->post('courseCode');
		$courseName = $this->input->post('courseName');
		$courseDesc = $this->input->post('courseDesc');
		$selectedCourse = $this->input->post('selectedCourse');

		$this->load->library('form_validation');
		$status = $this->form_validation->run('course');

		if ($status){

			$exist = $this->course_model->checkCourseExist($courseCode);

			if(count($exist)){

				$this->load->helper('form');
				$data = $this->getDatas($selectedCourse);
				$data['addCourseError'] = 2;
				$this->load->view('admin/maincourse.html', $data);

			} else {

				$result = $this->course_model->insertCourse($courseCode, $courseName, $courseDesc);

				$data = $this->getDatas($courseCode);

				if ($result == 1){
					$data['formMessage'] = "Successfully add a new course " . $courseCode . " : " . $courseName . ".";
				} else {
					$data['formMessage'] = "Failed to add a new course " . $courseCode . " : " . $courseName . ".";
				}

				$data['formResult'] = $result;
				$data['formSet'] = 1;

				$this->load->view('admin/maincourse.html', $data);
			}
		} else {

			$this->load->helper('form');
			$data = $this->getDatas($selectedCourse);
			$data['addCourseError'] = 1;
			$this->load->view('admin/maincourse.html', $data);
		}

	}

	public function deleteCourse(){

		$this->checkLogin();
		
		$courseCode = $this->input->post('courseCode');

		$modules = $this->course_model->getModulesByCourse($courseCode);
		
		if(count($modules)){
			
			$data = $this->getDatas($courseCode);
			$data['formMessage'] = "Failed to delete course " . $courseCode . ". There is still modules in this couse." ;	
			$data['formResult'] = 0;

		} else {

			$result = $this->course_model->deleteCourse($courseCode);

			$courses = $this->course_model->getCourses();

			if(!count($courses)){
				redirect('admin/courses_empty.html');
			}else{

				$newcourseCode = $courses[0]['courseCode'];
				$data = $this->getDatas($newcourseCode);

				if ($result == 1){
					$data['formMessage'] = "Successfully delete course " . $courseCode . ".";
				} else {
					$data['formMessage'] = "Failed to delete course " . $courseCode . ".";
				}

				$data['formResult'] = $result;
			}
		}

		$data['formSet'] = 1;	
		$this->load->view('admin/maincourse.html', $data);
	} 
}

