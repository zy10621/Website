<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Module extends CI_Controller{

    /**
     * [__construct description]
     */
    public function __construct()
    {
        parent::__construct();
    }



    /**
     * [checkLogin description]
     * @return [type]
     * 
     */
    public function checkLogin(){

        $isloggedin = $this->session_model->isAdminLogin();

        if(!$isloggedin){
            redirect('admin/login/index');
        }
    }


    public function index(){

        $this->checkLogin();

    	$modules = $this->admin_model->getModules();
        if(count($modules)){
    	   $this->modulePage($modules[0]['moduleCode']);
        } else {
            redirect('admin/modules_empty.html');
        }
    }

    public function modules(){

        $this->checkLogin();

        $moduleCode = $this->uri->segment(4);

        $this->modulePage($moduleCode);
    }

    public function modulePage($moduleCode){

        $this->checkLogin();

    	$data = $this->getDatas($moduleCode);
    	$this->load->view('admin/modules.html', $data);
    }


    public function getDatas($moduleCode){

        $this->checkLogin();

        // $data['courses'] = $this->course_model->getCourses();
        $data['allTutors'] = $this->admin_model->getTutors();
    	$data['modules'] = $this->admin_model->getModules();
    	$data['selectedModule'] = $moduleCode;
		$data['studentNotInModule'] = $this->admin_model->getStudentsNotInModule($moduleCode);
        $data['tutorNotInModule'] = $this->admin_model->getTutorNotInModule($moduleCode);
		$data['students'] = $this->admin_model->getStudentsByModule($moduleCode);   
        $data['tutors'] = $this->admin_model->getTutorByModule($moduleCode); 	

		return $data;
    }

    public function mainModule(){
        
        $this->checkLogin();

        $moduleCode = $this->input->post('moduleCode');

        $data = $this->getDatas($moduleCode);
        $this->load->view('admin/mainmodule.html', $data);
    }

    public function getStudentTutorByRegexp(){

        $this->checkLogin();

        $regexp = $this->input->post('regexp');
        $moduleCode = $this->input->post('moduleCode');
        $selected= $this->input->post('selected');

        if($regexp == ""){
            $regexp = ".*";
        }

        $data = $this->getDatas($moduleCode);

        $data['tutors']=$this->admin_model->getTutorByRegex($moduleCode,$regexp);
        $data['students'] = $this->admin_model->getStudentByRegex($moduleCode,$regexp);
        $data['selected'] = $selected;
        
        $this->load->view('admin/moduleTable.html', $data);
    }

    public function deleteStudentFromModule(){

        $this->checkLogin();

        $moduleCode = $this->input->post('moduleCode');
        $studentID = $this->input->post('studentID');

        $result = $this->admin_model->deleteStudentFromModule($moduleCode,$studentID);

        $data = $this->getDatas($moduleCode);

        if ($result == 1) {
            $data['formMessage'] = "Successfully removed " . $studentID . " from " . $moduleCode . "." ;
        } else {
            $data['formMessage'] = "Failed to remove " . $studentID . " from " . $moduleCode . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainmodule.html', $data);
    }

    public function deleteTutorFromModule(){

        $this->checkLogin();

        $tutorID = $this->input->post('tutorID');
        $moduleCode = $this->input->post('moduleCode');

        $result = $this->admin_model->deleteTutorFromModule($moduleCode, $tutorID);

        $data = $this->getDatas($moduleCode);

        if ($result == 1) {
            $data['formMessage'] = "Successfully removed " . $tutorID . " from " . $moduleCode . "." ;
        } else {
            $data['formMessage'] = "Failed to remove " . $tutorID . " from " . $moduleCode . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainmodule.html', $data);
    }

    public function addStudentIntoModule(){

        $this->checkLogin();

        $studentID = $this->input->post('studentID');
        $moduleCode = $this->input->post('moduleCode');

        $result = $this->admin_model->insertStudent($studentID, $moduleCode);

        $data = $this->getDatas($moduleCode);

        if ($result == 1) {
            $data['formMessage'] = "Successfully added student " . $studentID . " to " . $moduleCode . "." ;
        } else {
            $data['formMessage'] = "Failed to add student " . $studentID . " to " . $moduleCode . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainmodule.html', $data);
    }

    public function addTutorIntoModule(){

        $this->checkLogin();

        $tutorID = $this->input->post('tutorID');
        $moduleCode = $this->input->post('moduleCode');

        $result = $this->admin_model->insertTutor($tutorID, $moduleCode);

        $data = $this->getDatas($moduleCode);

        if ($result == 1) {
            $data['formMessage'] = "Successfully added tutor " . $tutorID . " to " . $moduleCode . "." ;
        } else {
            $data['formMessage'] = "Failed to add tutor " . $tutorID . " to " . $moduleCode . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/mainmodule.html', $data);
    }

    public function deleteModule(){

        $this->checkLogin();

        $moduleCode = $this->input->post('moduleCode');

        $students = $this->admin_model->getStudentsByModule($moduleCode);   
        $tutors = $this->admin_model->getTutorByModule($moduleCode); 
        $courses = $this->admin_model->getCourseByModule($moduleCode);

        if(count($students)){

            $data = $this->getDatas($moduleCode);
            $data['formMessage'] = "Failed to delete module " . $moduleCode . ". There are still students in this module." ;   
            $data['formResult'] = 0;
        } elseif (count($tutors)){

            $data = $this->getDatas($moduleCode);
            $data['formMessage'] = "Failed to delete module " . $moduleCode . ". There are still tutors in this module." ;   
            $data['formResult'] = 0;
        } elseif (count($courses)){

            $data = $this->getDatas($moduleCode);
            $data['formMessage'] = "Failed to delete module " . $moduleCode . ". There are still courses using this module." ;   
            $data['formResult'] = 0;
        } else {

            $result = $this->admin_model->deleteModule($moduleCode);

            $modules = $this->admin_model->getModules();


            if(!(count($modules))){
                redirect('admin/modules_empty.html');
            } else {
                
                $newmoduleCode = $modules[0]['moduleCode'];
                $data = $this->getDatas($newmoduleCode);

                if ($result == 1){
                    $data['formMessage'] = "Successfully delete module " . $moduleCode . ".";
                } else {
                    $data['formMessage'] = "Failed to delete module " . $moduleCode . ".";
                }

                $data['formResult'] = $result;
            }
        }

        $data['formSet'] = 1;   
        $this->load->view('admin/mainmodule.html', $data);
    
    }

    public function addModuleFromEmpty(){

        $this->checkLogin();
        
        $moduleCode = $this->input->post('moduleCode');
        $moduleName = $this->input->post('moduleName');
        $moduleSemester = $this->input->post('moduleSemester');
        $moduleCredit = $this->input->post('moduleCredit');
        $moduleLecturer = $this->input->post('moduleLecturer');
        $moduleLevel = $this->input->post('moduleLevel');
        $moduleWebCourseID = $this->input->post('moduleWebCourseID');
        $moduleWebYearID = $this->input->post('moduleWebYearID');

        $this->load->library('form_validation');
        $status = $this->form_validation->run('module');

        if ($status){

            $exist = $this->admin_model->checkModuleExist($moduleCode);

            if(count($exist)){

                $data['addModuleError'] = 2;
                $this->load->view('admin/modules_empty.html', $data);
                
            } else {

                $result = $this->admin_model->addModule($moduleCode, $moduleName, $moduleSemester, $moduleCredit, 
                                      $moduleLecturer, $moduleLevel,$moduleWebCourseID, $moduleWebYearID);

                $data = $this->getDatas($moduleCode);
                
                if ($result == 1){
                    $data['formMessage'] = "Successfully create a module " . $moduleCode . ".";
                } else {
                    $data['formMessage'] = "Failed to create a module " . $moduleCode . ": check your input";
                }

                $data['formResult'] = $result;
                $data['formSet'] = 1;   
                redirect('admin/module/index');  
            }
        } else {

            $data['addModuleError'] = 1;
            $this->load->view('admin/modules_empty.html', $data);
        }
    }

    public function addModule(){

        $this->checkLogin();
        
        $moduleCode = $this->input->post('moduleCode');
        $moduleName = $this->input->post('moduleName');
        $moduleSemester = $this->input->post('moduleSemester');
        $moduleCredit = $this->input->post('moduleCredit');
        $moduleLecturer = $this->input->post('moduleLecturer');
        $moduleLevel = $this->input->post('moduleLevel');
        $moduleWebCourseID = $this->input->post('moduleWebCourseID');
        $moduleWebYearID = $this->input->post('moduleWebYearID');
        $selectedModule = $this->input->post('selectedModule');

        $this->load->library('form_validation');
        $status = $this->form_validation->run('module');

        if ($status){

            $exist = $this->admin_model->checkModuleExist($moduleCode);

            if(count($exist)){

                $data = $this->getDatas($selectedModule);
                $data['addModuleError'] = 2;
                $this->load->view('admin/mainmodule.html', $data);
                
            } else {

                $result = $this->admin_model->addModule($moduleCode, $moduleName, $moduleSemester, $moduleCredit, 
                                      $moduleLecturer, $moduleLevel,$moduleWebCourseID, $moduleWebYearID);

                $data = $this->getDatas($moduleCode);
                
                if ($result == 1){
                    $data['formMessage'] = "Successfully create a module " . $moduleCode . ".";
                } else {
                    $data['formMessage'] = "Failed to create a module " . $moduleCode . ": check your input";
                }

                $data['formResult'] = $result;
                $data['formSet'] = 1;   
                $this->load->view('admin/mainmodule.html', $data);  
            }
        } else {

            $data = $this->getDatas($selectedModule);
            $data['addModuleError'] = 1;
            $this->load->view('admin/mainmodule.html', $data);
        }
    }
}



