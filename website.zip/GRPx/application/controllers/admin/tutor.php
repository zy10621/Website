<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Tutor extends CI_Controller{

	public function __construct()
    {
        parent::__construct();
    }

    public function checkLogin(){

        $isloggedin = $this->session_model->isAdminLogin();

        if(!$isloggedin){
            redirect('admin/login/index');
        }
    }

    public function index(){

        $this->checkLogin();

    	$tutors = $this->admin_model->getTutors();

    	$this->tutorPage($tutors[0]['tutorID']);
    }

    public function tutors(){

        $this->checkLogin();

        $tutorID = $this->uri->segment(4);

        $this->tutorPage($tutorID);
    }


    public function tutorPage($tutorID){

        $this->checkLogin();

    	$data = $this->getDatas($tutorID);
    	$this->load->view('admin/tutors.html', $data);
    }

    public function getDatas($tutorID){

        $this->checkLogin();

    	$data['selectedTutor'] = $tutorID; 
    	$data['selectedTutorName'] = $this->admin_model->getTutorNameByID($tutorID);
    	$data['tutors'] = $this->admin_model->getTutors();
    	$data['modulesNotWithTutor'] = $this->admin_model->getModulesNotWithTutor($tutorID);
    	$data['module'] = $this->admin_model->getModuleByTutor($tutorID);

    	return $data;
    }

    public function mainTutor(){

        $this->checkLogin();

    	$tutorID = $this->input->post('tutorID');

    	$data = $this->getDatas($tutorID);
    	$this->load->view('admin/maintutor.html', $data);
    }

    public function getModuleByRegexp(){

        $this->checkLogin();

    	$tutorID = $this->input->post('tutorID');
    	$regexp  = $this->input->post('regexp');
    	
    	if($regexp == ""){
    		$regexp = ".*";
    	}

    	$data = $this->getDatas($tutorID);
    	$data['module'] = $this->admin_model->getModuleByRegexp($tutorID, $regexp);

    	$this->load->view('admin/tutortable.html', $data);
    }

    public function deleteModule(){

        $this->checkLogin();

    	$tutorID = $this->input->post('tutorID');
    	$moduleCode = $this->input->post('moduleCode');

    	$result = $this->admin_model->deleteModuleByTutor($tutorID, $moduleCode);

    	$data=$this->getDatas($tutorID);

		if ($result == 1) {
            $data['formMessage'] = "Successfully removed " . $moduleCode . " from " . $tutorID . "." ;
        } else {
            $data['formMessage'] = "Failed to remove " . $moduleCode . " from " . $tutorID . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/maintutor.html', $data);
    }

    public function addModule(){

        $this->checkLogin();

    	$moduleCode = $this->input->post('moduleCode');
    	$tutorID = $this->input->post('tutorID');

    	$result = $this->admin_model->addModuleByTutor($tutorID, $moduleCode);

    	$data=$this->getDatas($tutorID);

		if ($result == 1) {
            $data['formMessage'] = "Successfully enrolled " . $tutorID . " onto " . $moduleCode . "." ;
        } else {
            $data['formMessage'] = "Failed to enroll " . $tutorID . " onto " . $moduleCode . " : please check your choice."; 
        }

        $data['formResult'] = $result;
        $data['formSet'] = 1;

        $this->load->view('admin/maintutor.html', $data);
    }

    public function deleteTutor(){

        $this->checkLogin();

    	$tutorID = $this->input->post('tutorID');
    	$modules = $this->admin_model->getModuleByTutor($tutorID);

    	if(count($modules)){
    		$data = $this->getDatas($tutorID);
            $data['formMessage'] = "Failed to remove " . $tutorID . ". There are still modules taught by this tutor." ;   
            $data['formResult'] = 0;
    	} else {
    		
    		$result = $this->admin_model->deleteTutor($tutorID);

            $tutors = $this->admin_model->getTutors();
    		$newTutor = $tutors[0]['tutorID'];

    		$data = $this->getDatas($newTutor);

			if ($result == 1){
                $data['formMessage'] = "Successfully removed " . $tutorID . ".";
            } else {
                $data['formMessage'] = "Failed to remove " . $tutorID . ".";
            }

            $data['formResult'] = $result;

    	}

    	$data['formSet'] = 1;   
        $this->load->view('admin/maintutor.html', $data);
    }

    public function addTutor(){

        $this->checkLogin();
        
    	$tutorID = $this->input->post('tutorID');
    	$tutorName = $this->input->post('tutorName');
    	$tutorPW = $this->input->post('tutorPW');

    	$result = $this->admin_model->addTutor($tutorID, $tutorName, $tutorPW);

    	$data = $this->getDatas($tutorID);

		if ($result == 1){
            $data['formMessage'] = "Successfully added tutor " . $tutorID . ".";
        } else {
            $data['formMessage'] = "Failed to add tutor " . $tutorID . ".";
        }

        $data['formResult'] = $result;
    	$data['formSet'] = 1;   
        $this->load->view('admin/maintutor.html', $data);
    }




}