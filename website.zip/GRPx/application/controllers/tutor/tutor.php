<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Tutor extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
    }

	public function index(){

		$this->checkLogin();

		$tutorID = $this->session_model->getTutorLoginID();

		$data['modules'] = $this->tutor_model->getModule($tutorID);
		$moduleCode = $data['modules'][0]['moduleCode'];

		$data = $this->getPages($moduleCode);
	}

	public function checkLogin(){

		$isloggedin = $this->session_model->isTutorLogin();

		if(!$isloggedin){
			redirect('tutor/login/index');
		}
	}

	public function getTables($moduleCode){

		$this->checkLogin();
		$tutorID = $this->session_model->getTutorLoginID();

		$data['tutorID'] = $tutorID;
		$data['tutorName'] = $this->session_model->getTutorLoginName();
		$data['modules'] = $this->tutor_model->getModule($tutorID);
		$data['students'] = $this->tutor_model->getStudent($moduleCode);
		$data['selectedModuleCode'] = $moduleCode;
		$data['studentsGrade'] = $this->tutor_model->getGradesStudents($moduleCode);
		$data['studentsCourse'] = $this->tutor_model->getCoursesStudents($moduleCode);

		return $data;
	}

	public function getPages($modCode){

		$this->checkLogin();

		if(($moduleCode = $this->uri->segment(4))==""){
			$moduleCode = $modCode;
		}

		$data = $this->getTables($moduleCode);		
		
		$this->load->view('tutor/tutor.html', $data);
	}

	public function viewPage(){

		$this->checkLogin();
		$tutorID = $this->session_model->getTutorLoginID();

		$moduleCode = $this->uri->segment(4);

		$data = $this->getTables($moduleCode);

		$this->load->view('tutor/pages.html', $data);			
	}

	public function getStudentByRegexp(){

		$regexp = $this->input->post('regexp');
		$moduleCode = $this->input->post('moduleCode');

		if($regexp == ""){
			$regexp = ".*";
		}

		$data['students']=$this->tutor_model->getStudentByRegex($moduleCode,$regexp);
		$this->load->view('tutor/selected_students.html', $data);
	}
	
}
