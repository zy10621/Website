<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Login extends CI_Controller{

	public function index(){
		$this->load->helper('form');
		$this->load->view('tutor/login.html');
	}

	public function check_login(){

		$this->load->library('form_validation');
		$status = $this->form_validation->run('tutor');

		if ($status){

			$tutorID= $this->input->post('tutorID');

			$tutorPW = md5($this->input->post('tutorPW'));
			
			$tutorData = $this->tutor_model->check($tutorID);

			if(!$tutorData || md5($tutorData[0]['tutorPW']) != $tutorPW){
				
				//need an error infromation here
				$data['error'] = 1;

				$this->load->helper('form');
				$this->load->view('tutor/login.html', $data);
			} else {

				//correct input
				$tutorName = $this->tutor_model->getName($tutorID);
				$this->session_model->setTutorLogin($tutorID, $tutorName);

				redirect('tutor/tutor/index');
			}
		} else {

			//invalid input
			$this->load->helper('form');
			$this->load->view('tutor/login.html');
		}
	}

	public function tutorlogout(){
		
		$this->session_model->tutorLogOut();
		
		$this->load->helper('form');
		redirect('tutor/login/index');
	}
}