<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Session_model extends CI_Model
{
    function __construct() {
        parent::__construct();
    }

    public function setStudentLogin($studentID, $studentName) {

        $sessionData = array(

                'studentlogin' => 'True',
                'studentID'     => $studentID,
                'studentName'   => $studentName,
                'logintime' => time()
                );

        $this->session->set_userdata($sessionData);
    }

    public function setAdminLogin($adminID, $adminName){

        $sessionData = array(

                'adminlogin' => 'True',
                'adminID'     => $adminID,
                'adminName'   => $adminName,
                'logintime' => time()
                );

        $this->session->set_userdata($sessionData);

    }

    public function setTutorLogin($tutorID, $tutorName){

        $sessionData = array(

                'tutorlogin' => 'True',
                'tutorID'     => $tutorID,
                'tutorName'   => $tutorName,
                'logintime' => time()
                );

        $this->session->set_userdata($sessionData);
    }

    public function studentLogOut() {
        $this->session->unset_userdata('studentlogin');
    }

    public function adminLogOut() {
        $this->session->unset_userdata('adminlogin');
    }

    public function tutorLogOut(){
        $this->session->unset_userdata('tutorlogin');
    }

    public function isTutorLogin(){
        return ($this->session->userdata('tutorlogin') == 'True');
    }

    public function isAdminLogin(){
        return ($this->session->userdata('adminlogin') == 'True');
    }

    public function isStudentLogin() {
        return ($this->session->userdata('studentlogin') == 'True');
    }

    public function getTutorLoginName() {
        return $this->session->userdata('tutorName');
    }

    public function getTutorLoginID(){
        return $this->session->userdata('tutorID');
    }

    public function getAdminLoginName() {
        return $this->session->userdata('adminName');
    }

    public function getAdminLoginID(){
        return $this->session->userdata('adminID');
    }

    public function getStudentLoginName() {
        return $this->session->userdata('studentName');
    }

    public function getStudentLoginID(){
        return $this->session->userdata('studentID');
    }
} 