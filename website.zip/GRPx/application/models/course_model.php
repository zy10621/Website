<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Course_model extends CI_Model{

	public function getCourses(){

		$data = $this->db->get('Course')->result_array();
		return $data;
	}

	public function getModulesByCourse($courseCode){

		$data = $this->db->query
			("SELECT * FROM Module NATURAL JOIN CourseModule WHERE courseCode= '" . $courseCode . "'")
		->result_array();

		return $data;
	}

	public function checkCourseExist($courseCode){

		$data = $this->db->query
			("SELECT * FROM Course WHERE courseCode = '" . $courseCode . "'")
		->result_array();
		
		return $data;
	}

	public function deleteModuleFromCourse($moduleCode, $courseCode){

		$this->db->query
			("DELETE FROM CourseModule WHERE moduleCode ='" . $moduleCode . "'AND courseCode = '" . $courseCode . "'");
	}

	public function getModulesNotInCourse($courseCode){

		$data = $this->db->query
			("SELECT moduleCode FROM Module WHERE moduleCode NOT IN (SELECT moduleCode FROM CourseModule WHERE courseCode = '" . $courseCode ."')")
		->result_array();

		return $data;
	}

	public function addModule($moduleCode, $courseCode, $compulsory){

		$result = $this->db->query
			("INSERT INTO CourseModule (courseCode, moduleCode, compulsory) VALUES ('" . $courseCode  . "', '" . $moduleCode . "', '" . $compulsory . "')");

		return $result;
	}

	public function getModuleByRegex($courseCode, $regexp){

		$data = $this->db->query
			("SELECT * FROM Module NATURAL JOIN CourseModule WHERE courseCode= '" . $courseCode . "' AND moduleCode REGEXP '" . $regexp . "'" )
		->result_array();

		return $data;
	}

	public function insertCourse($courseCode, $courseName, $courseDesc){

		$result = $this->db->query
			("INSERT INTO Course VALUES('" . $courseCode .  "', '" . $courseName . "', '" . $courseDesc . "')" );

		return $result;
	}

	public function deleteCourse($courseCode){

		$result = $this->db->query
			("DELETE FROM Course WHERE courseCode = '" . $courseCode . "'");

		return $result;
	}
}









