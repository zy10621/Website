<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Tutor_model extends CI_Model{

	/**
	* check tutor
	*/
	public function check($tutorID){
		// $this->db->where(array('username'=>$username))->get('admin')->result_array();
		$data = $this->db->get_where('Tutor', array('tutorID'=>$tutorID))->result_array();
		return $data;
	}

	public function getName($tutorID){
		$data = $this->db->query("SELECT tutorName FROM Tutor WHERE tutorID = '" . $tutorID . "'")->result_array();
		return $data[0]['tutorName'];
	}

	public function getModule($tutID){

		$data = $this->db->select('moduleCode')->get_where('TutorModule', array('tutorID' => $tutID ))->result_array();
		return $data;
	}

	public function getStudent($moduleCode){

		$data = $this->db->query
		("SELECT studentID, studentName, stuGrade FROM StudentModule NATURAL JOIN Student 
			WHERE moduleCode = '" . $moduleCode . "' AND currentYear = TRUE")
		->result_array();

		return $data;
	}

	public function getGradesStudents ($moduleCode){

		$data['grade1'] = $this->getStudentByGrade($moduleCode,1);
		$data['grade2'] = $this->getStudentByGrade($moduleCode,2);
		$data['grade3'] = $this->getStudentByGrade($moduleCode,3);

		return $data;
	}

	public function getStudentByGrade($moduleCode, $grade){

		$data = $this->db->query
		("SELECT COUNT(studentID) AS numStuGrade FROM `StudentModule` NATURAL JOIN `Student` 
			WHERE moduleCode = '" . $moduleCode . "' AND currentYear = TRUE AND stuGrade = '" . $grade . "';")
		->result_array();
		
		return $data[0]['numStuGrade'];
	}

	public function getStudentByRegex($moduleCode, $regexp){

		$data = $this->db->query
		("SELECT studentID, studentName, stuGrade FROM StudentModule NATURAL JOIN Student 
			WHERE moduleCode = '" . $moduleCode . "' AND currentYear = TRUE AND (studentID REGEXP '" . $regexp . "' OR studentName REGEXP '" . $regexp . "')")
		->result_array();		
		return $data;
	}

	public function getCoursesStudents ($moduleCode){

		$data['G400'] = $this->getStudentByCourse($moduleCode, 'G400');
		$data['G601'] = $this->getStudentByCourse($moduleCode, 'G601');
		$data['G4G7'] = $this->getStudentByCourse($moduleCode, 'G4G7');

		return $data;
	}

	public function getStudentByCourse ($moduleCode, $courseCode){

		$data = $this->db->query
		("SELECT COUNT(studentID) AS numStuCorse FROM `StudentModule` NATURAL JOIN `Student` 
			WHERE moduleCode = '" . $moduleCode . "' AND currentYear = TRUE AND courseCode = '" . $courseCode . "';")
		->result_array();

		return $data[0]['numStuCorse'];
	}
}




