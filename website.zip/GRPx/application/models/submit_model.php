<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Submit_model extends CI_Model{

	protected $NOT_FULL_CREDIT_ERROR = 1;
	protected $OVER_FULL_CREDIT_ERROR = 2;
	protected $AUTUMN_CREDITS_FULL_ERROR = 3;
	protected $AUTUMN_CREDITS_NOT_ENOUGH_ERROR = 4;
	protected $SPRING_CREDITS_FULL_ERROR = 5;
	protected $SPRING_CREDITS_NOT_ENOUGH_ERROR = 6;
	protected $EXIST_HIGHER_GRADE_ERROR = 7;
	protected $TOO_MUCH_HIGHER_GRAGE_ERROR = 8;

	protected $CODE_SUCCESS = 0;
	
	public function index($stuID){

		$seasonCredits = $this->module_model->calSeasonCredits($stuID);
		$levelCredits = $this->module_model->calLevelCredits($stuID);


		$total = $this->module_model->calTotal($stuID);

		if ($total < 120){

			$data=array(
				'condition' =>  $this->NOT_FULL_CREDIT_ERROR,
				'explaination' => "The total credits must be 120!",
				);
			return $data;

		} else if ($total > 120){

			$data=array(
				'condition' =>  $this->OVER_FULL_CREDIT_ERROR,
				'explaination' => "The total credits must be 120!",
				);
			return $data;
		}

		$spring = $seasonCredits['spring'];
		$autumn = $seasonCredits['autumn'];

		if ($spring > 70){

			$data=array(
				'condition' =>  $this->SPRING_CREDITS_FULL_ERROR,
				'explaination' => "The minimum credit of one semester is 50 and the maximum is 70.",
				);
			return $data;

		} else if ($spring < 50){

			$data=array(
				'condition' =>  $this->SPRING_CREDITS_NOT_ENOUGH_ERROR,
				'explaination' => "The minimum credit of one semester is 50 and the maximum is 70.",
				);
			return $data;
		}

		if ($autumn > 70){

			$data=array(
				'condition' =>  $this->AUTUMN_CREDITS_FULL_ERROR,
				'explaination' => "The minimum credit of one semester is 50 and the maximum is 70.",
				);
			return $data;

		} else if ($spring < 50){

			$data=array(
				'condition' =>  $this->AUTUMN_CREDITS_NOT_ENOUGH_ERROR,
				'explaination' => "The minimum credit of one semester is 50 and the maximum is 70.",
				);
			return $data;
		}
			
		$level1 = $levelCredits['level1'];
		$level2 = $levelCredits['level2'];
		$level3 = $levelCredits['level3'];
		$level4 = $levelCredits['level4'];

		$currentGrade = $this->module_model->getGrade($stuID);

		if (($currentGrade == 1 && ($level2 != 0 || $level3 != 0 || $level4 != 0))
		 || ($currentGrade == 2 && ($level3 != 0 || $level4 != 0))){
			
			$data=array(
				'condition' =>  $this->EXIST_HIGHER_GRADE_ERROR,
				'explaination' => "You cannot choose a higher grage level!",
				);
			return $data;
		}
		
		$data=array(
			'condition' =>  $this->CODE_SUCCESS,
			'explaination' => "Your choices have been saved",
			);
		return $data;
	}
}