<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student_Model extends CI_Model{

	/**
	* check student
	*/
	public function check($studentID){
		// $this->db->where(array('username'=>$username))->get('admin')->result_array();
		$data = $this->db->get_where('Student', array('studentID'=>$studentID))->result_array();
		return $data;
	}

	/**
	* change password
	*/
	public function change($uid, $data){
		$this->db->update('Admin', $data, array('uid'=>$uid));
	}

	public function finish($studentID){
		$this->db->update('Student', array('completeChoice' => TRUE), array('studentID'=>$studentID));
	} 

	public function checkFinished($studentID){
		$data = $this->db->select('completeChoice')->get_where('Student', array('studentID'=>$studentID))->result_array();
		return $data[0]['completeChoice'];
	}

	public function getName($studentID){
		$data = $this->db->query
			("SELECT studentName FROM Student WHERE studentID = '" . $studentID . "'")
		->result_array();

		return $data[0]['studentName'];
	}
}