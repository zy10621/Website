<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Module_model extends CI_Model{

	public function getCourseCode($stuID){

		$data = $this->db->select('courseCode')->get_where('Student', array('studentID'=>$stuID))->result_array();
		return $data[0]['courseCode'];
	}

	public function getStuGrade($stuID){

		$data = $this->db->select('stuGrade')->get_where('Student', array('studentID' => $stuID ))->result_array();
		return $data[0]['stuGrade'];
	}

	public function getNotChosen($stuID, $courseCode){
		 
		$grade = $this->getStuGrade($stuID);

		$data = $this->db->query
			("SELECT moduleCode, moduleName, moduleSememster, moduleCredit, moduleWebCourseID, moduleWebYearID FROM CourseModule NATURAL JOIN Module 
				WHERE moduleLevel = '" . $grade . "'  AND courseCode = '" . $courseCode . "' AND (compulsory = '0') 
					AND (moduleCode NOT IN (SELECT moduleCode FROM StudentModule WHERE currentYear = 1 AND studentID = '" . $stuID . "'));")
				->result_array();
		return $data;
	}

	public function getChosen($stuID, $courseCode){

		$data = $this->db->query(
				"SELECT * FROM Module NATURAL JOIN StudentModule WHERE currentYear = 1 AND studentID = '" . $stuID . "'")
					->result_array();

		return $data;
	}

	public function getCompulsory($stuID, $courseCode){

		$grade = $this->getStuGrade($stuID);

		$data = $this->db->query(
			"SELECT moduleCode, moduleName, moduleSememster, moduleCredit, moduleLevel, moduleWebCourseID, moduleWebYearID 
				FROM Module NATURAL JOIN CourseModule 
					WHERE moduleLevel = '" . $grade . "' 
						AND (compulsory = '1') 
						AND courseCode = '" . $courseCode ."';")
			->result_array();
			
		return $data;
	}

	public function calChosenCredits($stuID){

		$courseCode = $this->getCourseCode($stuID);
		$chosen = $this->getChosen($stuID, $courseCode);
		
		$sum = 0;
		foreach ($chosen as $temp) :

			$sum += $temp['moduleCredit'];
		endforeach;
			
		return $sum;
	}

	public function calCompulsoryCredits($stuID){

		$courseCode = $this->getCourseCode($stuID);
		$compulsory = $this->getCompulsory($stuID, $courseCode);
		
		$sum = 0;
		foreach ($compulsory as $temp) :

			$sum += $temp['moduleCredit'];
		endforeach;
			
		return $sum;
	}

	public function calSeasonCredits($stuID){

		$courseCode = $this->getCourseCode($stuID);
		$compulsory = $this->getCompulsory($stuID, $courseCode);
		$chosen = $this->getChosen($stuID, $courseCode);


		$spring = 0;
		$autumn = 0;
		foreach ($compulsory as $temp) :
				
			if ($temp['moduleSememster'] == 'Autumn') {
				$autumn += $temp['moduleCredit'];
			} else if ($temp['moduleSememster'] == "Full Year"){
				$spring += $temp['moduleCredit']/2;
				$autumn += $temp['moduleCredit']/2;
			} else {
				$spring += $temp['moduleCredit'];
			}
			
		endforeach;

		foreach ($chosen as $temp) :
				
			if ($temp['moduleSememster'] == 'Autumn') {		
				$autumn += $temp['moduleCredit'];
			} else if ($temp['moduleSememster'] == "Full Year"){
				$spring += $temp['moduleCredit']/2;
				$autumn += $temp['moduleCredit']/2;
			} else {
				$spring += $temp['moduleCredit'];
			}
			
		endforeach;
		
		$data = array(
					'autumn' => $autumn,
					'spring' => $spring
				);
	
		return $data;
	}

	public function calLevelCredits($stuID){

		$courseCode = $this->getCourseCode($stuID);
		$compulsory = $this->getCompulsory($stuID, $courseCode);
		$chosen = $this->getChosen($stuID, $courseCode);

		$level1 = 0;
		$level2 = 0;
		$level3 = 0;
		$level4 = 0;

		foreach ($compulsory as $temp) :
			
			$level = $temp['moduleLevel'];
			$credit = $temp['moduleCredit'];

			if ($level == 1){ $level1 += $credit; }
			if ($level == 2){ $level2 += $credit; }
			if ($level == 3){ $level3 += $credit; }
			if ($level == 4){ $level4 += $credit; }
			
		endforeach;

		foreach ($chosen as $temp) :
			
			$level = $temp['moduleLevel'];
			$credit = $temp['moduleCredit'];

			if ($level == 1){ $level1 += $credit; }
			if ($level == 2){ $level2 += $credit; }
			if ($level == 3){ $level3 += $credit; }
			if ($level == 4){ $level4 += $credit; }
			
		endforeach;
		
		$data = array(
					'level1' => $level1,
					'level2' => $level2,
					'level3' => $level3,
					'level4' => $level4
				);
		return $data;
	}

	public function getGrade($stuID){
		$grade = $this->db->select('stuGrade')->get_where('Student', array('studentID'=>$stuID))->result_array();
		return $grade[0]['stuGrade'];
	}

	public function calTotal($stuID){

		$chosenCredits = $this->calChosenCredits($stuID);
		$compulsoryCredits = $this->calCompulsoryCredits($stuID);

		return $chosenCredits + $compulsoryCredits;
	}

	public function addModule($data){
		$this->db->insert('StudentModule', $data);
	}

	public function deleteModule($data){
		$this->db->delete('StudentModule',$data);
	}

}



