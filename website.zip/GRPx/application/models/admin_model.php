<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model{

	/**
	* check admin
	*/
	public function check($adminID){
		// $this->db->where(array('username'=>$username))->get('admin')->result_array();
		$data = $this->db->get_where('Admin', array('adminID'=>$adminID))->result_array();
		return $data;
	}

	public function getFinishedStudent(){
		$data = $this->db->query
			("SELECT * FROM Student WHERE completeChoice = 1 ")
		->result_array();

		return $data;
	}

	public function getStudentsCountDetail(){
	
		$data['year1G400'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G400' and stuGrade = 1")->result_array()[0]['count'];
		$data['year2G400'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G400' and stuGrade = 2")->result_array()[0]['count'];
		$data['year3G400'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G400' and stuGrade = 3")->result_array()[0]['count'];
		$data['year1G4G7'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G4G7' and stuGrade = 1")->result_array()[0]['count'];
		$data['year2G4G7'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G4G7' and stuGrade = 2")->result_array()[0]['count'];
		$data['year3G4G7'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G4G7' and stuGrade = 3")->result_array()[0]['count'];
		$data['year1G601'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G601' and stuGrade = 1")->result_array()[0]['count'];
		$data['year2G601'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G601' and stuGrade = 2")->result_array()[0]['count'];
		$data['year3G601'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G601' and stuGrade = 3")->result_array()[0]['count'];

		$data['G400'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G400'")->result_array()[0]['count'];
		$data['G4G7'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G4G7'")->result_array()[0]['count'];
		$data['G601'] = $this->db->query("SELECT COUNT(studentID) as count FROM Student WHERE completeChoice = 1 and courseCode = 'G601'")->result_array()[0]['count'];

		return $data;
	}

	public function getName($adminID){
		$data = $this->db->query
			("SELECT adminName FROM Admin WHERE adminID = '" . $adminID . "'")
		->result_array();
		
		return $data[0]['adminName'];
	}

	public function getModules(){

		$data = $this->db->query
			("SELECT * FROM Module")
		->result_array();

		return $data;
	}

	public function getStudentsNotInModule($moduleCode){

		$data = $this->db->query
			("SELECT studentID, studentName FROM Student WHERE studentID NOT IN (SELECT studentID FROM StudentModule WHERE currentYear = '1' AND moduleCode = '" . $moduleCode . "')")
		->result_array();

		return $data;
	}

	public function getTutorNotInModule($moduleCode){

		$data = $this->db->query
			("SELECT tutorID, tutorName FROM Tutor WHERE tutorID NOT IN (SELECT tutorID FROM TutorModule WHERE tutorID = '" . $moduleCode . "')")
		->result_array();

		return $data;
	}

	public function checkModuleExist($moduleCode){

		$data = $this->db->query
			("SELECT * FROM Module WHERE moduleCode = '" . $moduleCode . "'")
		->result_array();

		return $data;
	}

	public function getStudentsByModule($moduleCode){

		$data = $this->db->query
			("SELECT * FROM StudentModule NATURAL JOIN Student WHERE currentYear = '1' AND moduleCode = '" . $moduleCode . "'")
		->result_array();

		return $data;
	}

	public function getTutorByModule($moduleCode){

		$data = $this->db->query
			("SELECT * FROM TutorModule NATURAL JOIN Tutor WHERE moduleCode = '" . $moduleCode . "'")
		->result_array();

		return $data;
	}

	public function getTutorByRegex($moduleCode,$regexp){

		$data = $this->db->query
			("SELECT * FROM Tutor NATURAL JOIN TutorModule WHERE moduleCode= '" . $moduleCode . "' AND tutorID REGEXP '" . $regexp . "'" )
		->result_array();

		return $data;
	}

	public function getStudentByRegex($moduleCode,$regexp){

		$data = $this->db->query
			("SELECT * FROM Student NATURAL JOIN StudentModule WHERE currentYear = '1' AND moduleCode= '" . $moduleCode . "' AND studentID REGEXP '" . $regexp . "'" )
		->result_array();

		return $data;
	}

	public function deleteStudentFromModule($moduleCode,$studentID){

		$result = $this->db->query
			("DELETE FROM StudentModule WHERE moduleCode = '" . $moduleCode . "' AND studentID = '" . $studentID . "'");

		return $result;	
	}

	public function deleteTutorFromModule($moduleCode, $tutorID){

		$result = $this->db->query
			("DELETE FROM TutorModule WHERE moduleCode = '" . $moduleCode . "' AND tutorID = '" . $tutorID . "'");

		return $result;	
	}

	public function insertStudent($studentID, $moduleCode){

		$result = $this->db->query
			("INSERT INTO StudentModule (moduleCode, studentID, currentYear) VALUES ('" . $moduleCode . "', '" . $studentID . "', 1)");

		return $result;
	}

	public function insertTutor($tutorID, $moduleCode){

		$result = $this->db->query
			("INSERT INTO TutorModule (moduleCode, tutorID) VALUES ('" . $moduleCode . "', '" . $tutorID . "')");

		return $result;
	}

	public function deleteModule($moduleCode){

		$result = $this->db->query
			("DELETE FROM Module WHERE moduleCode = '" . $moduleCode . "'");

		return $result;
	}

	public function getCourseByModule($moduleCode){

		$data = $this->db->query
			("SELECT * FROM CourseModule WHERE moduleCode = '" . $moduleCode . "'" )
		->result_array();

		return $data;
	}

	public function getTutors(){

		$data = $this->db->query
			("SELECT * FROM Tutor")
		->result_array();

		return $data;
	}

	public function addModule($moduleCode, $moduleName, $moduleSemester, $moduleCredit, 
                                      $moduleLecturer, $moduleLevel,$moduleWebCourseID, $moduleWebYearID){

		$result = $this->db->query
			("INSERT INTO Module VALUES ('" . $moduleCode . "', '" .  $moduleName .  "', '" . $moduleCredit 
				. "', '" . $moduleLevel . "', '" . $moduleSemester . "', '" . $moduleLecturer . "', '" 
				. $moduleWebCourseID . "', '" . $moduleWebYearID . "')" );

		return $result;
	}

	public function getModulesNotWithTutor($tutorID){

		$data = $this->db->query
			("SELECT * FROM Module WHERE moduleCode NOT IN (SELECT moduleCode FROM TutorModule WHERE tutorID = '" . $tutorID . "')")
		->result_array();

		return $data;
	}

	public function getModuleByTutor($tutorID){

		$data = $this->db->query
			("SELECT * FROM TutorModule NATURAL JOIN Module WHERE tutorID = '" . $tutorID . "'")
		->result_array();

		return $data;
	}

	public function getTutorNameByID($tutorID){

		$data = $this->db->query
			("SELECT tutorName FROM Tutor WHERE tutorID = '" . $tutorID . "'")
		->result_array();

		return $data[0]['tutorName'];
	}

	public function getModuleByRegexp($tutorID, $regexp){

		$data = $this->db->query
			("SELECT * FROM TutorModule NATURAL JOIN Module 
				WHERE tutorID = '" . $tutorID . "' AND 
				( moduleCode REGEXP '" . $regexp . "' OR moduleName REGEXP '" . $regexp . "')")
		->result_array();

		return $data;
	}

	public function deleteModuleByTutor($tutorID, $moduleCode){

		$result = $this->db->query
			("DELETE FROM TutorModule WHERE tutorID = '" . $tutorID . "' AND moduleCode = '" . $moduleCode . "'");

		return $result;
	}

	public function addModuleByTutor($tutorID, $moduleCode){

		$result = $this->db->query
			("INSERT INTO TutorModule (tutorID, moduleCode) VALUES ('" . $tutorID . "', '" . $moduleCode . "')");
	
		return $result;
	}

	public function deleteTutor($tutorID){

		$result = $this->db->query
			("DELETE FROM Tutor WHERE tutorID = '" . $tutorID . "'");

		return $result;
	}

	public function addTutor($tutorID, $tutorName, $tutorPW){

		$result = $this->db->query
			("INSERT INTO Tutor VALUES ('" . $tutorID . "', '" . $tutorPW . "', '" . $tutorName . "')");

		return $result;
	}

	public function getStudents(){

		$data = $this->db->query
			("SELECT * FROM Student")
		->result_array();

		return $data;
	}

	public function getStudentNameByID($studentID){

		$data = $this->db->query
			("SELECT studentName FROM Student WHERE studentID = '" . $studentID . "'")
		->result_array();

		return $data[0]['studentName'];
	}

	public function getModulesNotWithStudent($studentID, $moduleLevel, $courseCode){

		$data = $this->db->query
		("SELECT * FROM Module WHERE moduleCode NOT IN ( SELECT moduleCode FROM StudentModule WHERE currentYear = '1' AND studentID = '" . $studentID . "')
		AND moduleCode NOT IN (SELECT moduleCode FROM CourseModule NATURAL JOIN Module WHERE moduleLevel = '" . $moduleLevel . "' AND 
		compulsory = '1' AND courseCode = '" . $courseCode . "')")
		->result_array();

		return $data;
	}

	public function getModuleByStudent($studentID){

		$data = $this->db->query
			("SELECT * FROM StudentModule NATURAL JOIN Module WHERE currentYear = '1' AND studentID = '" . $studentID . "'")
		->result_array();

		return $data;
	}

	public function getStudentModuleByRegexp($studentID, $regexp){

		$data = $this->db->query
			("SELECT * FROM StudentModule NATURAL JOIN Module 
				WHERE currentYear = '1' AND studentID = '" . $studentID . "' AND ( moduleCode REGEXP '" . $regexp . "' OR moduleName REGEXP '" . $regexp . "')")
		->result_array();

		return $data;
	}

	public function getStuComModuleByRegexp($courseCode, $regexp, $level){

		$data = $this->db->query
			("SELECT * FROM CourseModule NATURAL JOIN Module 
				WHERE compulsory = 1 AND moduleLevel = '" . $level . "' AND courseCode = '" . $courseCode . 
				"' AND (moduleCode REGEXP '" . $regexp . "' OR moduleName REGEXP '" . $regexp . "')")
		->result_array();

		return $data;
	}

	public function getCourseCodeByStudent($studentID){

		$data = $this->db->query
			("SELECT courseCode FROM Student WHERE studentID = '" . $studentID . "'")
		->result_array();

		return $data[0]['courseCode'];
	}

	public function getCompulsory($courseCode, $moduleLevel){

		$data = $this->db->query
			("SELECT * FROM CourseModule NATURAL JOIN Module 
				WHERE compulsory = 1 AND moduleLevel = '" . $moduleLevel . "' AND courseCode = '" . $courseCode . "'")
		->result_array();

		return $data;
	}

 	public function getLevelBySdudent($studentID){

 		$data = $this->db->query
 			("SELECT stuGrade FROM Student WHERE studentID = '" . $studentID . "'")
 		->result_array();

 		return $data[0]['stuGrade'];
 	}

	public function addModuleIntoStudent($studentID, $moduleCode){

		$result = $this->db->query
			("INSERT INTO StudentModule (studentID, moduleCode, currentYear) 
				VALUES ('" . $studentID . "', '" . $moduleCode . "', 1)");

		return $result;
	}

	public function deleteModulesFromStudent($studentID){

		$result = $this->db->query
			("DELETE FROM StudentModule WHERE studentID = '" . $studentID . "'");

		return $result;
	}

	public function deleteModuleByStudent($studentID, $moduleCode){

		$result = $this->db->query
			("DELETE FROM StudentModule WHERE studentID = '" . $studentID . "' AND moduleCode = '" . $moduleCode . "'");

		return $result;
	}

	public function resetStudent($studentID){

		$result = $this->db->query
			("UPDATE Student SET completeChoice = 0 WHERE studentID = '" . $studentID . "'");

		return $result;
	}

	public function setStudent($studentID){

		$result = $this->db->query
			("UPDATE Student SET completeChoice = 1 WHERE studentID = '" . $studentID . "'");

		return $result;
	}
}











