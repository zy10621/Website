<script src="<?php echo base_url('assets/js/custom_table.js') ?>"></script>

    <div class="col-md-8" >
        <!-- Left table -->
        <table class="table table-hover">
            <caption>Optional Module</caption>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Code</th>
                    <th>Module Title</th>
                    <th>Semester</th>
                    <th>Credits</th>
                </tr>
            </thead>
            <tbody>

            <?php foreach ($notChosen as $temp): ?>
               <tr> 
                    <td>
                        <?php 
                            if (!$finished){

                                echo '<button type="button"';
                                echo ' name="' . $temp['moduleCode'] . '"'; 
                                echo ' onclick="$.addCourse(this)"';
                                echo 'class="btn btn-success btn-xs btn-circle">+</button>';

                            }
                        ?>
                    </td>
                    <td class='clickable-row' data-href="<?php echo "http://modulecatalogue.nottingham.ac.uk/nottingham/asp/moduledetails.asp?crs_id=" . $temp['moduleWebCourseID'] . "&year_id=" . $temp['moduleWebYearID'] ?>" ><?php echo $temp['moduleCode'] ?></td>
                    <td class='clickable-row' data-href="<?php echo "http://modulecatalogue.nottingham.ac.uk/nottingham/asp/moduledetails.asp?crs_id=" . $temp['moduleWebCourseID'] . "&year_id=" . $temp['moduleWebYearID'] ?>"><?php echo $temp['moduleName'] ?></td>
                    <td class='clickable-row' data-href="<?php echo "http://modulecatalogue.nottingham.ac.uk/nottingham/asp/moduledetails.asp?crs_id=" . $temp['moduleWebCourseID'] . "&year_id=" . $temp['moduleWebYearID'] ?>"><?php echo $temp['moduleSememster'] ?></td>
                    <td class='clickable-row' data-href="<?php echo "http://modulecatalogue.nottingham.ac.uk/nottingham/asp/moduledetails.asp?crs_id=" . $temp['moduleWebCourseID'] . "&year_id=" . $temp['moduleWebYearID'] ?>"><?php echo $temp['moduleCredit'] ?></td>  
                
                </tr>
            <?php endforeach ?>
            </tbody>
        </table>
    </div>

    <div class="col-md-4">  
        <table class="table table-hover">
            <caption>Selected Modules</caption>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Code</th>
                    <th>Semester</th>
                    <th>Credits</th>

                </tr>
            </thead>
            <tbody>
            <!-- not compulsory -->
            <?php foreach ($chosen as $temp): ?>
               
                <tr>
                    <td>
                        <?php 
                            if (!$finished){

                                echo '<button type="button"';
                                echo ' name="' . $temp['moduleCode'] . '"'; 
                                echo ' onclick="$.delCourse(this)"';
                                echo 'class="btn btn-danger btn-xs btn-circle">-</button>';

                            }
                        ?>                        
                    </td>
                    <td><?php echo $temp['moduleCode'] ?></td>
                    <td><?php echo $temp['moduleSememster'] ?></td>
                    <td><?php echo $temp['moduleCredit'] ?></td>
                </tr>

            <?php endforeach ?>

            <!-- compulsory -->

            <?php foreach ($compulsory as $temp): ?>
               
                <tr>
                    <td></td>
                    <td><?php echo $temp['moduleCode'] ?></td>
                    <td><?php echo $temp['moduleSememster'] ?></td>
                    <td><?php echo $temp['moduleCredit'] ?></td>
                </tr>

            <?php endforeach ?>

                <tr>
                    <td></td>
                    <td></td>
                    <td>Total :</td>
                    <td><strong><?php echo $total ?></strong></td>
                </tr>
            </tbody>
        </table>
    </div>




        