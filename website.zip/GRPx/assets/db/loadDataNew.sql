DELETE FROM `TutorModule`;
DELETE FROM `StudentModule`;
DELETE FROM `CourseModule`; 
DELETE FROM `Module`;
DELETE FROM `Student`;
DELETE FROM `Course`;
DELETE FROM `Tutor`;
DELETE FROM `Admin`;
DELETE FROM `CourseDirector`;

INSERT INTO `CourseDirector` VALUES ('psztpp', '123456', 'Tony Pridmore');

INSERT INTO `Admin` VALUES ('admin', 'admin', '123456');

INSERT INTO `Course` VALUES
	
	('G400', 'Computer Science BSc Hons', 'This course is designed to produce high-quality 
										   graduates who show independent thought, flexibility 
										   and maturity, and who command a sound technical 
										   knowledge of the broad aspects of computer science. 
										   All our courses are compliant with the Association 
										   for Computing Machinery (ACM) and the Institute of 
										   Electrical and Electronic Engineers (IEEE). We are 
										   one of the first higher education institutions in 
										   the country to be in line with these internationa-
										   lly recognised educational requirements. You will 
										   gain an appreciation of current computing practice 
										   so that the skills you learn can be applied immed-
										   iately after graduation. The course also provides 
										   an understanding of the nature of computer science 
										   as an academic discipline.'),

	('G4G7', 'Computer Science with AI BSc Hons', 'This course is designed to produce high-quality 
											graduates who show independent thought, flexibility 
											and maturity, and who command a sound technical 
											knowledge of the broad aspects of computer science. 
											All our courses are compliant with the Association 
											for Computing Machinery (ACM) and the Institute of 
											Electrical and Electronic Engineers (IEEE). We are 
											one of the first higher education institutions in 
											the country to be in line with these internationally 
											recognised educational requirements. You will gain 
											an appreciation of current computing practice so that 
											the skills you learn can be applied immediately after 
											graduation. The course also provides an understanding 
											of the nature of computer science as an academic discipline. 

											You will learn about current computing practice that 
											can be applied immediately after graduation, founda-
											tional aspects of computing that will be of lasting 
											value as technology changes over time, and research-
											level topics that will play an important role in 
											future developments.'),

	('G601', 'Software Engineering BSc Hons', 'TBC');
	
INSERT INTO `Student` (studentID, studentPW, studentName, stuGrade, courseCode, studentSex, firstLogIn) VALUES

		('psyxs1', '123456', 'Xu Sun', '2', 'G400', 'M', '0'),
		('psyly2', '123456', 'Lan YAO', '3', 'G400', 'F', '0'),
		('psyql1', '123456', 'Qingyuandi LIN', '2', 'G4G7', 'F', '0'),
		('psytq',  '123456', 'Ting QIAO', '2', 'G4G7', 'M', '0'),
		('psyhz2', '123456', 'Haozhe ZHANG', '2', 'G400', 'M', '0'),
		('psycb3', '123456', 'Christopher Birmingham', '2', 'G400', 'M', '0'),
		('psyam7', '123456', 'Amoul Mangat', '2', 'G400', 'M', '0'),
		('psykdd', '123456', 'Kawthar Djameela Dulloo', '2', 'G400', 'F', '0'),
		('psydae', '123456', 'Daniel Aidan Evans', '2', 'G400', 'M', '0'),
		('psyyz11', '123456', 'Yuncan Zhang', '2', 'G400', 'M', '0'),

		('psyyte1', '123456', 'Tony Evans', '1', 'G400', 'M', '0'),
		('psydsa2', '123456', 'Daniel Logan', '1', 'G4G7', 'M', '0'),
		('psyeuq3', '123456', 'Michel Parkes', '1', 'G400', 'M', '0'),
		('psyuqk1', '123456', 'Max Rodden', '1', 'G400', 'M', '0'),

		('psyytw1', '123456', 'Ender Silva', '3', 'G601', 'M', '0'),
		('psydta2', '123456', 'Jenna Lehre', '3', 'G400', 'F', '0'),
		('psybuq3', '123456', 'Stefan John', '3', 'G4G7', 'M', '0'),
		('psyuok1', '123456', 'Julie Tennent', '3', 'G400', 'F', '0'),

		('psy4tw1', '123456', 'Jonathan Hutton', '2', 'G4G7', 'M', '0'),
		('psydtk2', '123456', 'Uwe Maere', '2', 'G400', 'F', '0'),
		('psyb3q3', '123456', 'Greensmith Atkin', '2', 'G400', 'M', '0'),
		('psyuoe1', '123456', 'Lehre Evans', '2', 'G601', 'F', '0');



INSERT INTO `Tutor` VALUES
		(  'pszcah', '123456',          'Colin Higgins'),
		(  'pszajp',    '123456',       'Andrew Parkes'),
		(  'pszmvr',   '123456',   'Milena Radenkovic'),
		(    'pszpt',    '123456',        'Paul Tennent'),
		(  'psznhn',    '123456',      'Henrik Nilsson'),
		(   'pszjg1',    '123456',    'Julie Greensmith'),
		(   'pszja',    '123456',         'Jason Atkin'),
		(   'pszgd',   '123456',      'Geert de Maere'),
		(      'itzbl',    '123456',           'Li Bai'),
		(  'pszgmh',    '123456','Graham Hutton'),
		(    'pszgtr',    '123456',        'Gail Hopkins'),
		('psztxa',    '123456', 'Thorsten Altenkirch'),
		(    'psztpp',    '123456', 'Tony Pridmore'),
		('pszbsl', '123456', 'Brian Logan'),
		('pszrij', '123456', 'Robert John'),
		('pszsrb', '123456', 'Steven Bagley'),
		('pszpl', '123456', 'Per Lehre'),
		('pszbnk', '123456', 'Boriana Koleva'),
		('pszjmg', '123456', 'Jonathan Garibaldi'),
		('pszyt', '123456', 'Yorgos Tzimiropoulos'),
		('pszrq', '123456', 'Rong Qu'),
		('pszuxa', '123456', 'Uwe Aickelin'),
		('pszjr', '123456', 'Jenna Reps'),
		('pszmw', '123456', 'Max Wilson'),
		('pszeo', '123456', 'Ender Ozcan'),
		('pszmv', '123456', 'Michel Valstar'),
		('pszsre', '123456', 'Stefan Rennick Egglestone'),
		('pszcw', '123456', 'Christian Wagner'),
		('pszjds', '123456', 'Dario Landa Silva'),
		('pszmdf', '123456', 'Martin Flintham'),
		('psztar', '123456', 'Tom Rodden'),
		('pszvc', '123456', 'Venanzio Capretta'),
		('pszsdb', '123456', 'Steve Benford'),
		('pszaxc', '123456', 'Andy Crabtree'),
		('pszjm2', '123456', 'Joseph Marshall'),
		('pszsr', '123456', 'Stuart Reeves'),
		('pszds1', '123456', 'Daniele Soria'),
		('psztc', '123456', 'Tim Coughlan'),
		('pszcmg', '123456', 'Christopher Greenhalgh'),
		('epzscn', '123456', 'Sarah Sharples'),
		('psznza', '123456', 'Natasha Alechina'),
		('pszps', '123456', 'Peer-olaf Siebers'),
		('pszpxb', '123456', 'Peter Blanchfield'),
		('sbzapf', '123456', 'Andrew French'),
		('epzsmr', '123456', 'Svetan Ratchev'),
		('enzces', '123456', 'Colin Snape'),
		('ezzcjt', '123456', 'Christopher Tuck');

INSERT INTO `Module` VALUES

		('G52APR', 'Application Programming', '10', '2', 'Autumn','Dr Colin Higgins', '021311',  '000114'),
		('G52ADS', 'Algorithms and Data Structures', '10', '2', 'Autumn','Dr Andrew Parkes', "007255", "000114"),
		('G52CCN', 'Computer Communications and Networks', '10', '2', 'Spring', 'Dr M Radenkovic', '002252', '000114'),
		('G52GRP', 'Software Engineering Group Project', '20', '2', 'Full Year', 'Mr P Tennent', '008415', '000114'),
		('G52MAL', 'Machines and their Languages', '10', '2', 'Spring', 'Dr H Nilsson', '018194', '000114'),
		('G52SEM', 'Software Engineering Methodologies', '10', '2', 'Autumn', 'Dr J Greensmith', '021243', '000114'),
		('G52OSC', 'Operating Systems & Concurrency', '20', '2', 'Spring', 'Dr J Atkin and Dr G De Maere', '025400', '000114'),
		('G52GUI', 'Graphical User Interfaces', '10', '2', 'Spring', 'Dr L Bai', '018177', '000114'),
		('G52AFP', 'Advanced Functional Programming', '10', '2', 'Spring', 'Professor G Hutton', '018180', '000114'),
		('G52HCI', 'Human Computer Interaction', '10', '2', 'Autumn', 'Dr G Hopkins', '007255', '000114'),
		('G52IFR', 'Introduction to Formal Reasoning','10', '2', 'Autumn', 'Dr T Altenkirch', '021216', '000114'),
		('G52IIP', 'Introduction to Image Processing', '10', '2', 'Autumn', 'Professor T Pridmore', '021218', '000114'),
		('G52CPP', 'C++ Programming',  '10', '2', 'Spring', 'Dr J Atkin','022258', '000114'),
		('G52PSA', 'Planning, Search and Artificial Intelligence Programming', '20', '2', 'Full Year', 'Dr B Logan and Professor R John', '025024', '000114'),
		('G51CSA', 'Computer Systems Architecture', '10', '1', 'Autumn', 'Dr S Bagley', '002235', '000114'),
		('G51MFC', 'Mathematical Foundations of Computer Science', '20', '1', 'Autumn', 'Dr P Lehre and Professor R John', '025023', '000014'),
		('G51PRG', 'Introduction to Programming', '20', '1', 'Autumn', 'Dr S Bagley', '012192', '000114'),
		('G51WPS', 'Web Programming and Scripting', '10', '1', 'Autumn', 'Dr B Koleva', '017011', '000114'),
		('G51DBS', 'Database Systems', '10', '1', 'Spring', 'Professor J Garibaldi and Dr Y Tzimiropoulos', '016949', '000114'),
		('G51FUN', 'Introduction to Functional Programming', '10', '1', 'Spring', 'Professor G Hutton', '007252', '000114'),
		('G51IAI', 'Introduction to Artificial Intelligence', '10', '1', 'Spring', 'Dr R Qu', '016973', '000114' ),
		('G51IMO', 'Introduction to Modelling and Optimisation', '10', '1', 'Spring', 'Professor U Aickelin and Miss J Reps', '025039', '000114'),
		('G51ISO', 'Introduction to Software Engineering & Object-Oriented Programming', '20', '1', 'Spring', 'Dr C Higgins and Dr M Wilson', '025399', '000114'),
		('G53IDS', 'Individual Dissertation Single Honours', '40', '3', 'Full Year', 'Dr H Nilsson', '008462', '000114'),
		('G53COM', 'Computability', '10', '3', 'Spring', 'Dr A Parkes', '002268', '000114'),
		('G53DSM', 'Automated Decision Support Methodologies', '20', '3', 'Spring', 'Dr E Ozcan', '018196', '000114'),
		('G53FUZ', 'Fuzzy Sets and Fuzzy Logic Systems', '10', '3', 'Spring', 'Professor J Garibaldi', '023393', '000114'),
		('G53GRA', 'Computer Graphics', '10', '3', 'Spring', 'Dr L Bai', '021221', '000114'),
		('G53MLE', 'Machine Learning', '20', '3', 'Spring', 'Dr M Valstar', '021211', '000114'),
		('G53NMD', 'New Media Design', '10', '3', 'Spring', 'Mr S Rennick Egglestone', '021217', '000114'),
		('G53OPS', 'Operating Systems', '10', '3', 'Spring', 'Dr G De Maere', '002276', '000114'),
		('G53SEC', 'Computer Security', '10', '3', 'Spring', 'Dr J Greensmith', '018176', '000114'),
		('G53ARS', 'Autonomous Robotic Systems', '10', '3', 'Autumn', 'Dr C Wagner', '023421', '000114'),
		('G53CCD', 'Collaboration and Communication Technologies Development Project', '10', '3', 'Autumn', 'Dr M Wilson', '025296', '000114'),
		('G53CCT', 'Collaboration and Communication Technologies', '10', '3', 'Autumn', 'Dr M Wilson', '021220', '000114'),
		('G53CMP', 'Compilers', '10', '3', 'Autumn', 'Dr H Nilsson', '021224', '000114'),
		('G53CWO', 'Computers in the World', '10', '3', 'Autumn', 'Dr D Landa Silva', '023374', '000114'),
		('G53GAM', 'Games', '10', '3', 'Autumn', 'Dr M Flintham', '025098', '000114'),
		('G53KRR', 'Knowledge Representation and Reasoning', '10', '3', 'Autumn', 'Dr R Qu', '018195', '000114'),
		('G53SQM', 'Software Quality Management', '10', '3', 'Autumn', 'Professor T Rodden', '022254', '000114');

INSERT INTO `CourseModule` (courseCode, moduleCode, compulsory) VALUES
		
		( 'G400', 'G52ADS', '1'),
		( 'G400', 'G52APR', '1'),
		( 'G400', 'G52CCN', '1'),
		( 'G400', 'G52SEM', '1'),
		( 'G400', 'G52GRP', '1'),
		( 'G400', 'G52MAL', '1'),
		( 'G400', 'G52OSC', '1'),
		( 'G400', 'G52GUI', '0'),
		( 'G400', 'G52AFP', '0'),
		( 'G400', 'G52HCI', '0'),
		( 'G400', 'G52IFR', '0'),
		( 'G400', 'G52IIP', '0'),
		( 'G400', 'G52CPP', '0'),
		( 'G400', 'G52PSA', '0'),
		( 'G400', 'G51CSA', '1'),
		( 'G400', 'G51MFC', '1'),
		( 'G400', 'G51PRG', '1'),
		( 'G400', 'G51WPS', '0'),
		( 'G400', 'G51DBS', '1'),
		( 'G400', 'G51FUN', '1'),
		( 'G400', 'G51IAI', '1'),
		( 'G400', 'G51IMO', '0'),
		( 'G400', 'G51ISO', '1'),
		( 'G400', 'G53IDS', '1'),
		( 'G400', 'G53COM', '0'),
		( 'G400', 'G53DSM', '0'),
		( 'G4G7', 'G52ADS', '1'),
		( 'G4G7', 'G52APR', '1'),
		( 'G4G7', 'G52CCN', '1'),
		( 'G4G7', 'G52SEM', '1'),
		( 'G4G7', 'G52GRP', '1'),
		( 'G4G7', 'G52MAL', '1'),
		( 'G4G7', 'G52OSC', '1'),
		( 'G4G7', 'G52GUI', '0'),
		( 'G4G7', 'G52AFP', '0'),
		( 'G4G7', 'G52HCI', '0'),
		( 'G4G7', 'G52IFR', '0'),
		( 'G4G7', 'G52IIP', '0'),
		( 'G4G7', 'G52CPP', '0'),
		( 'G4G7', 'G52PSA', '0'),
		( 'G4G7', 'G51CSA', '1'),
		( 'G4G7', 'G51MFC', '1'),
		( 'G4G7', 'G51PRG', '1'),
		( 'G4G7', 'G51WPS', '0'),
		( 'G4G7', 'G51DBS', '1'),
		( 'G4G7', 'G51FUN', '1'),
		( 'G4G7', 'G51IAI', '1'),
		( 'G4G7', 'G51IMO', '0'),
		( 'G4G7', 'G51ISO', '1'),
		( 'G4G7', 'G53IDS', '1'),
		( 'G4G7', 'G53COM', '0'),
		( 'G4G7', 'G53DSM', '0');



INSERT INTO `TutorModule` (tutorID, moduleCode) VALUES
		('pszcah',  'G52APR'),
		('pszcah',  'G51ISO'),
		('pszajp', 'G52ADS'),
		('pszajp', 'G53COM'),
		('pszmvr', 'G52CCN'),
		('pszpt',   'G52GRP'),
		('psznhn', 'G52MAL'),
		('psznhn', 'G53IDS'),
		('psznhn', 'G53CMP'),
		('pszjg1', 'G52SEM'),
		('pszjg1', 'G53SEC'),
		('pszja', 'G52OSC'),
		('pszja', 'G52CPP'),
		('pszgd', 'G52OSC'),
		('pszgd', 'G53OPS'),
		('itzbl',    'G52GUI'),
		('itzbl',    'G53GRA'),
		('pszgmh', 'G52AFP'),
		('pszgmh', 'G51FUN'),
		('pszgtr',   'G52HCI'),
		('psztxa', 'G52IFR'),
		('psztpp',   'G52IIP'),
		('pszbsl',  'G52PSA'),
		('pszrij', 'G52PSA'),
		('pszrij', 'G51MFC'),
		('pszsrb', 'G51CSA'),
		('pszsrb', 'G51PRG'),
		('pszpl', 'G51MFC'),
		('pszbnk', 'G51WPS'),
		('pszjmg','G51DBS'),
		('pszjmg','G53FUZ'),
		('pszyt',  'G51DBS'),
		('pszrq', 'G51IAI'),
		('pszrq',    'G53KRR'),
		('pszuxa',     'G51IMO'),
		('pszjr',   'G51IMO'),
		('pszmw',     'G51ISO'),
		('pszmw',     'G53CCD'),
		('pszmw',     'G53CCT'),
		('pszeo',   'G53DSM'),
		('pszmv',  'G53MLE'),
		('pszsre',  'G53NMD'),
		('pszcw', 'G53ARS'),
		('pszjds',   'G53CWO'),
		('pszmdf',  'G53GAM'),
		('psztar',     'G53SQM');

INSERT INTO `StudentModule` (studentID, moduleCode) VALUES

	('psyyte1', 'G51IAI'),
	('psydsa2', 'G51IAI'),
	('psyeuq3', 'G51IAI'),
	('psyuqk1', 'G51IAI'),
	('psy4tw1', 'G51IAI'),
	('psydtk2', 'G51IAI'),
	('psyb3q3', 'G53KRR'),
	('psyuoe1', 'G53KRR'),
	('psyytw1', 'G53KRR'),
	('psydta2', 'G53KRR'),
	('psybuq3', 'G53KRR'),
	('psyuok1', 'G53KRR');









