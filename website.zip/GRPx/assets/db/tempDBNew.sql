DROP TABLE IF EXISTS `StudentModule`; 
DROP TABLE IF EXISTS `TutorModule`;
DROP TABLE IF EXISTS `CourseModule`;
DROP TABLE IF EXISTS `Module`; 
DROP TABLE IF EXISTS `Student`; 
DROP TABLE IF EXISTS `Course`; 
DROP TABLE IF EXISTS `Tutor`; 
DROP TABLE IF EXISTS `Admin`;
DROP TABLE IF EXISTS  `CourseDirector`;
DROP FUNCTION IF EXISTS `_nextval`;


CREATE TABLE `CourseDirector` (

	cdID VARCHAR (50) NOT NULL,
	cdPW VARCHAR (50) NOT NULL,
	cdName VARCHAR (255) NOT NULL,

	CONSTRAINT cdPK
		PRIMARY KEY (cdID)
);

CREATE TABLE `Admin` (

	adminID VARCHAR (50) NOT NULL ,
	adminName VARCHAR (255) NOT NULL,
	adminPW VARCHAR (50) NOT NULL ,

	CONSTRAINT adminPK
		PRIMARY KEY (adminID)
);

CREATE TABLE `Course` (

	courseCode VARCHAR(255) NOT NULL,
	courseName VARCHAR(255) NOT NULL,
	courseDesc TEXT NOT NULL,

	CONSTRAINT couPK 
		PRIMARY KEY (courseCode)
);

CREATE TABLE `Student` (

	studentID VARCHAR(255) NOT NULL,
	studentPW VARCHAR(255) NOT NULL,
	studentName VARCHAR(255) NOT NULL,
	stuGrade   INT NOT NULL,
	courseCode VARCHAR(255) NOT NULL,
	studentSex VARCHAR (20) DEFAULT NULL,
	firstLogIn BOOLEAN NOT NULL,
	completeChoice BOOLEAN NOT NULL DEFAULT FALSE,

	CONSTRAINT stuPK 
		PRIMARY KEY (studentID),
	CONSTRAINT stuCouFk FOREIGN KEY (courseCode)
		REFERENCES `Course` (courseCode)
);

CREATE TABLE `Tutor` (

	tutorID VARCHAR(255) NOT NULL,
	tutorPW VARCHAR(255) NOT NULL,
	tutorName VARCHAR (255) NOT NULL,

	CONSTRAINT tutorPK 
		PRIMARY KEY (tutorID)
);

CREATE TABLE `Module` (

	moduleCode VARCHAR(255) NOT NULL,
	moduleName VARCHAR(255) NOT NULL,
	moduleCredit INT NOT NULL,
	moduleLevel INT NOT NULL,
	moduleSememster VARCHAR(255) NOT NULL,
	moduleLecturer VARCHAR(255) NOT NULL,
	moduleWebCourseID VARCHAR(255) NOT NULL,
    moduleWebYearID VARCHAR(255) NOT NULL,

	CONSTRAINT modPK
		PRIMARY KEY (moduleCode),

	CHECK (module_taught 
		IN ('Spring', 'Autumn', 'Full Year'))
);

CREATE TABLE `TutorModule` (

	teaMouID INT AUTO_INCREMENT,
	tutorID VARCHAR (255) NOT NULL,
	moduleCode VARCHAR (255) NOT NULL,

	CONSTRAINT tutModPK
		PRIMARY KEY (teaMouID),
	CONSTRAINT tutModFK FOREIGN KEY (tutorID) 
		REFERENCES `Tutor` (tutorID),
	CONSTRAINT modTutFK FOREIGN KEY (moduleCode) 
		REFERENCES `Module` (moduleCode)
);

CREATE TABLE `CourseModule` (

	couModID INT AUTO_INCREMENT,
	courseCode VARCHAR(255) NOT NULL,
	moduleCode VARCHAR(255) NOT NULL,
	compulsory BOOLEAN NOT NULL,

	CONSTRAINT couModPK
		PRIMARY KEY (couModID),
	CONSTRAINT couModCK
		UNIQUE (courseCode, moduleCode),
	CONSTRAINT couModSouFK FOREIGN KEY (courseCode)
		REFERENCES `Course` (courseCode),
	CONSTRAINT couModModFK FOREIGN KEY (moduleCode)
		REFERENCES `Module` (moduleCode)
);

CREATE TABLE `StudentModule` (

	stuModID INT AUTO_INCREMENT,
	studentID VARCHAR(255) NOT NULL,
	moduleCode VARCHAR(255) NOT NULL,
	currentYear BOOLEAN DEFAULT TRUE,

	CONSTRAINT stuModPK 
		PRIMARY KEY (stuModID),
	CONSTRAINT stuModCK
		UNIQUE (studentID, moduleCode),
	CONSTRAINT stuModStuFK FOREIGN KEY (studentID)
		REFERENCES `Student` (studentID),
	CONSTRAINT stuModModFK FOREIGN KEY (moduleCode)
		REFERENCES `Module` (moduleCode)
);

DELIMITER //
CREATE FUNCTION `_nextval` (n VARCHAR(255)) RETURNS INTEGER
BEGIN
	DECLARE curval INT;
	SET curval = (SELECT curValue FROM `Sequence` 
				  	WHERE seqName = n);
	UPDATE `Sequence`
		SET curValue = curval + increasement
		WHERE seqName = n;

	RETURN curval;
END;