$(function () {
    $("ul.holder").jPages({
        containerID: "students-info",
        previous: "\«",
        next: "\u00bb",
        perPage: 9,
        delay: 20
    });
    
//    $("div.holder.jp-previous").addClass("");
//    $("ul.holder a").before("<li>");
//    $("ul.holder a").after("</li>");
//    $("ul.holder a").prepend("<li>");
//    $("ul.holder a").append("</li>");
});