$(function () {
    $("ul.holder").jPages({
        containerID: "modules-info",
        previous: "\«",
        next: "\u00bb",
        perPage: 9,
        delay: 20
    });
    
});