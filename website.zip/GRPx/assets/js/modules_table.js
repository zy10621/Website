$(function () {
    $("ul.holder").jPages({
        containerID: "students-info",
        previous: "\«",
        next: "\u00bb",
        perPage: 9,
        delay: 20
    });
    
});

$( "#students-tab" ).click(function() {
//  alert( "student." );
    $("ul.holder").show();
});

$( "#tutors-tab" ).click(function() {
//  alert( "tutors." );
    $("ul.holder").hide();
});